import { Patient } from './types';
// Entirely fictional training/demo records. Never use these as real patient data.
export const DEMO_PATIENTS: Patient[] = [
{id:'pat_104',number:104,age:29,gravida:2,para:2,type:'Obstetric',status:'Postpartum day 1',ward:'Postnatal',bed:'B-02',diagnosis:'Postpartum hypertension',attention:'high',attentionReason:'Elevated BP and headache documented in the demo record.',updatedAt:'06:20',handoverDone:false},
{id:'pat_142',number:142,age:31,gravida:1,para:0,gestation:'34 weeks',type:'Obstetric',status:'Antenatal admission',ward:'Antenatal',bed:'C-01',diagnosis:'Reduced fetal movements',attention:'monitor',attentionReason:'Admitted for assessment; review documented investigations.',updatedAt:'05:30',handoverDone:false},
{id:'pat_120',number:120,age:28,gravida:1,para:0,gestation:'39 weeks',type:'Obstetric',status:'Active labour',ward:'Labour room',bed:'L-03',diagnosis:'First stage of labour',attention:'high',attentionReason:'Demo record includes CTG concern; clinician review required.',updatedAt:'06:50',handoverDone:false},
{id:'pat_150',number:150,age:29,gravida:2,para:1,gestation:'30 weeks',type:'Obstetric',status:'HDU monitoring',ward:'HDU',bed:'H-02',diagnosis:'Severe pre-eclampsia',attention:'high',attentionReason:'High-dependency monitoring documented in demo record.',updatedAt:'06:00',handoverDone:false},
{id:'pat_116',number:116,age:26,gravida:3,para:2,type:'Obstetric',status:'Postpartum day 2',ward:'Postnatal',bed:'A-04',diagnosis:'Routine postnatal care',attention:'routine',attentionReason:'No additional concern documented in this demo record.',updatedAt:'04:45',handoverDone:true},
{id:'pat_131',number:131,age:34,type:'Gynaecology',status:'Post-operative day 1',ward:'Gynae',bed:'G-03',diagnosis:'Post-operative observation',attention:'monitor',attentionReason:'Continue documented post-operative observations.',updatedAt:'03:55',handoverDone:false}
];
