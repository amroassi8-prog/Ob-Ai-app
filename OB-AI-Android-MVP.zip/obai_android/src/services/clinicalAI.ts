import * as FileSystem from 'expo-file-system/legacy';
import { Finding } from '../types';

const API_URL = process.env.EXPO_PUBLIC_API_URL?.replace(/\/$/, '');

export async function persistAudioRecording(uri: string) {
  const dir = `${FileSystem.documentDirectory}obai-audio/`;
  await FileSystem.makeDirectoryAsync(dir, { intermediates: true }).catch(() => undefined);
  const destination = `${dir}recording-${Date.now()}.m4a`;
  await FileSystem.copyAsync({ from: uri, to: destination });
  return destination;
}

// Conservative on-device fallback: extracts only clear numeric observations and explicit phrases.
// It is never labelled as AI and always requires clinician review.
export function extractLocalDraft(text: string): Finding[] {
  const out: Finding[] = [];
  const add=(label:string,value:string,category:Finding['category'])=>out.push({id:`f_${out.length}_${Date.now()}`,label,value,category,certainty:'explicit'});
  const bp=text.match(/(?:BP|blood pressure|ضغط)\s*(?:is|:)?\s*(\d{2,3})\s*(?:\/|على)\s*(\d{2,3})/i);
  if(bp)add('Blood pressure',`${bp[1]}/${bp[2]} mmHg`,'Vital');
  const hr=text.match(/(?:HR|heart rate|pulse|نبض)\s*(?:is|:)?\s*(\d{2,3})\s*(?:bpm)?/i);
  if(hr)add('Heart rate',`${hr[1]} bpm`,'Vital');
  const temp=text.match(/(?:temperature|temp|حرارة)\s*(?:is|:)?\s*(\d{2}(?:\.\d)?)\s*°?\s*(?:C|درجة)?/i);
  if(temp)add('Temperature',`${temp[1]} °C`,'Vital');
  const spo=text.match(/(?:SpO2|oxygen saturation|saturation|تشبع)\s*(?:is|:)?\s*(\d{2,3})\s*%?/i);
  if(spo)add('SpO₂',`${spo[1]}%`,'Vital');
  const rr=text.match(/(?:RR|respiratory rate|معدل التنفس)\s*(?:is|:)?\s*(\d{1,2})/i);
  if(rr)add('Respiratory rate',`${rr[1]}/min`,'Vital');
  const lower=text.toLowerCase();
  const symptomTerms=[['Headache',['headache','صداع']],['Vaginal bleeding',['vaginal bleeding','bleeding','نزيف']],['Abdominal pain',['abdominal pain','ألم البطن']],['Visual symptoms',['visual symptoms','blurred vision','زغللة']],['Reduced fetal movements',['reduced fetal movements','قلة حركة الجنين']]] as const;
  for(const [label,terms] of symptomTerms){const term=terms.find(t=>lower.includes(t.toLowerCase()));if(term){const before=lower.slice(Math.max(0,lower.indexOf(term.toLowerCase())-24),lower.indexOf(term.toLowerCase()));const denied=/(no |denies |without |نفي|لا يوجد|ما في)\s*$/.test(before);add(label,denied?'Explicitly denied':'Reported — verify context','Symptom');}}
  if(!out.length)add('Clinical note','No reliable structured fields found. Review the original text and enter findings manually.','Other');
  return out;
}

export async function extractWithAI(text:string, patient:{id:string;number:number;status:string}) {
  if(!API_URL) throw new Error('AI service is not configured. The original note is still saved locally.');
  const response=await fetch(`${API_URL}/api/extract`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text,patient})});
  if(!response.ok) throw new Error((await response.json().catch(()=>({}))).error || `AI service error (${response.status})`);
  const data=await response.json();
  return data.findings as Finding[];
}

export async function transcribeAudio(uri:string) {
  if(!API_URL) throw new Error('Speech-to-text service is not configured. Keep the recording and enter a short text note instead.');
  const form=new FormData();
  form.append('audio',{uri,name:'clinical-update.m4a',type:'audio/mp4'} as any);
  const response=await fetch(`${API_URL}/api/transcribe`,{method:'POST',body:form});
  if(!response.ok) throw new Error((await response.json().catch(()=>({}))).error || `Transcription error (${response.status})`);
  const data=await response.json();
  if(!data.transcript) throw new Error('No transcript returned. The recording has not been converted to text.');
  return data.transcript as string;
}

export async function generateHandover(patient:any, events:any[]) {
  if(!API_URL) throw new Error('AI service is not configured. Review the documented events manually.');
  const response=await fetch(`${API_URL}/api/handover`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({patient,events})});
  if(!response.ok) throw new Error((await response.json().catch(()=>({}))).error || `Handover service error (${response.status})`);
  return (await response.json()).summary as string;
}
