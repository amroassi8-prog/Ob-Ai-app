export type Attention = 'high' | 'monitor' | 'routine';
export type EventStatus = 'draft' | 'confirmed';
export type Source = 'Quick text' | 'Voice' | 'Manual';
export interface Patient { id:string; number:number; age:number; gravida?:number; para?:number; gestation?:string; type:'Obstetric'|'Gynaecology'; status:string; ward:string; bed:string; diagnosis:string; attention:Attention; attentionReason:string; updatedAt:string; handoverDone:boolean; }
export interface Finding { id:string; label:string; value:string; category:'Vital'|'Symptom'|'Examination'|'Assessment'|'Plan'|'Other'; certainty:'explicit'|'uncertain'; }
export interface ClinicalEvent { id:string; patientId:string; createdAt:string; source:Source; rawText:string; findings:Finding[]; notes:string; status:EventStatus; author:string; }
export interface PendingAction { id:string; patientId:string; title:string; priority:'high'|'medium'|'low'; done:boolean; }
