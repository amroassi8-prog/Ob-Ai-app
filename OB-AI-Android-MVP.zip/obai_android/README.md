# OB-AI Android — rebuilt MVP foundation

**Platform:** Android application (React Native + Expo + TypeScript)  
**Purpose:** fast clinical capture, patient timeline, visible changes, and shift handover for Obstetrics & Gynaecology.

> **Important safety boundary:** this is an early development/demo build, not a clinically validated medical device or production hospital system. The included patient records are fictional. Do not enter identifiable or real patient information. Before any clinical pilot, implement authentication, role-based authorization, encrypted local storage, secure transport, audit logging, backup/recovery, data-retention controls, institutional approval, and clinical safety testing.

## What is in this version

- Native React Native Android UI; no HTML/WebView wrapper.
- Minimal navigation: Home, Patients, Handover.
- Patient overview and a concise event timeline.
- Quick text clinical capture.
- Native microphone recording using `expo-av`.
- Server-side speech transcription and structured extraction endpoints (Gemini; API key remains on server).
- Explicitly labelled local rule-based draft when AI is unavailable; never silently presented as AI.
- Clinician review/edit step before an entry can be marked confirmed.
- SQLite persistence on the device, including unconfirmed offline drafts and a durable sync queue.
- Concise handover generation using confirmed events only; no fabricated fallback summary.

## Deliberately removed from the first Android MVP

- Full nursing task management and medication administration workflows.
- Complex role-specific dashboards and HOD analytics.
- Automatic diagnoses or treatment suggestions.
- Automatic CTG/ultrasound interpretation.
- Fake AI responses, simulated recording, and invented default actions.
- Automatic handover completion without clinician confirmation.

These can be reconsidered after real clinicians validate the core workflow.

## Run the Android app

Requirements: Node.js LTS, npm, Android Studio/Android SDK (or Expo Go for an initial device preview).

```bash
npm install
npx expo start
```

Press `a` to launch an Android emulator, or scan the QR code with Expo Go on an Android phone. For a standalone Android build, configure EAS Build or a local Android build environment:

```bash
npx expo prebuild --platform android
npx expo run:android
```

## Run the AI backend

Copy `.env.example` to `.env`, set `GEMINI_API_KEY`, and install dependencies (already listed in `package.json`). Then:

```bash
npm run server
```

Set `EXPO_PUBLIC_API_URL` to the backend URL before starting Expo. Android emulator: `http://10.0.2.2:8787`. A physical phone must use the computer's reachable LAN IP, with both devices on the same network.

The backend exposes:

- `GET /health`
- `POST /api/transcribe` (multipart field `audio`)
- `POST /api/extract` (JSON `{ text, patient }`)
- `POST /api/handover` (JSON `{ patient, events }`)

The backend is a development scaffold only. It currently has no user authentication, authorization, rate limiting, hospital network controls, or production privacy controls. Do not expose it to the public internet or send real patient data.

## Clinical workflow

1. Select a fictional patient.
2. Add a short typed note or record a voice update.
3. Transcribe the recording if the backend is configured.
4. Request AI extraction, or explicitly choose the local draft parser.
5. Review and edit every finding against the original note.
6. Confirm and save to the local timeline, or save as an unconfirmed offline draft.
7. Generate a handover draft from confirmed events only; the receiving clinician must verify it.

## Known limitations / next engineering steps

1. Add secure authentication and bind every event to a verified account ID (current author is explicitly marked unverified).
2. Add encrypted SQLite storage and secure key management.
3. Implement a real authenticated sync protocol with idempotency, conflict handling, and server acknowledgements. The current sync queue is durable but is not yet automatically synchronized.
4. Add manual creation/completion of pending actions and a reconciliation view.
5. Improve Arabic/mixed-language transcription with real-world Gaza accents and clinical vocabulary testing.
6. Validate extraction against a clinician-authored dataset; measure omissions, false positives, negation handling, and correction rates.
7. Add accessible RTL Arabic UI and language switching.
8. Add evidence attachments only after secure storage and patient-link verification are implemented.
9. Add tests for database persistence, duplicate submission, offline restart, and clinical safety cases.
10. Obtain local clinical governance approval before any pilot.

## Legacy project review

See `LEGACY_REVIEW.md` for the assessment of the uploaded web prototype and decisions about what to retain, simplify, or rebuild.
