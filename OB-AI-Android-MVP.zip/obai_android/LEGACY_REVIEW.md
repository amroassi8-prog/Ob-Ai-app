# OB-AI legacy project review

Reviewed archive: `Ob-ai-main.zip` (Vite/React web application, 39 files, approximately 590 KB uncompressed source/assets).

## What is worth retaining conceptually

- The core product idea: capture once, organize, surface meaningful changes, and prepare handover.
- Patient identity and obstetric context (G/P, gestational age, ward/bed, admission type).
- Clinical event provenance: raw input, timestamp, source, author, review/confirmation status.
- Patient timeline and handover reconciliation as the central workflow.
- Existing synthetic case scenarios, especially #104 and #142, as test fixtures only.
- The Gemini server-side integration pattern (API key is not in the React client).

## What should be simplified

The legacy UI has 15 separate React components, including separate dashboards/modals for nursing tasks, admission, discharge, HOD time savings, metrics, print sheets, reconciliation, paper-note upload, medications, labs, procedures, and multiple capture modes. This is too much surface area for the first bedside Android pilot.

The Android MVP reduces navigation to Home, Patients, and Handover. Clinical capture is one screen with voice or text, followed by a single review/confirm step. The first version does not attempt to replace the hospital's admission, medication, lab, or nursing systems.

## Issues found in the legacy implementation

1. **Web-only architecture:** `src/App.tsx` uses DOM elements, browser APIs, Vite, and `localStorage`; this is not an Android native app.
2. **Browser-dependent voice:** `VoiceCaptureModal.tsx` uses `window.SpeechRecognition` / `webkitSpeechRecognition`; this is not a dependable Android-native speech pipeline and has no genuine audio upload path in that component.
3. **Offline queue data loss risk:** `syncOfflineQueue` in `src/context/AppContext.tsx` iterates queued items, then clears the entire queue regardless of whether each extraction succeeded. Failed items can be lost.
4. **Fabricated clinical fallback:** `generateHandoverSummaryForPatient` creates a handover summary after the remote AI call fails. It adds generic actions such as routine observations/consultant review that may not have been documented.
5. **Rule-extraction safety defects:** `extractClinicalDataRuleBased` in `server.ts` assigns symptom severity and can infer exam statements (for example, a normal lochia statement) from keyword matches. Negation detection is too broad in some cases and can misclassify symptoms.
6. **Overloaded scope:** the prototype includes medication, laboratory, nursing task, procedure, paper scan, CTG/ultrasound, metrics, and HOD workflows before validating the core capture-to-handover loop.
7. **Security gaps:** the API scaffold has no authentication/authorization or production access controls. Browser `localStorage` is not an appropriate store for sensitive clinical data.
8. **Synthetic identifiers and demo content:** useful for demonstration, but they must never be confused with live hospital records.

## Decisions in the Android rebuild

- React Native + Expo + TypeScript; no HTML wrapper.
- SQLite for local persistence and an explicit durable offline draft queue.
- Raw note remains visible and is retained alongside extracted fields.
- AI extraction is clearly distinguished from a basic local parser.
- A local parser is never described as AI and never silently substitutes for failed AI.
- Every extracted field is editable and requires clinician confirmation.
- Handover generation uses confirmed events only and fails visibly if AI is unavailable; no fabricated summary.
- Demo records are explicitly fictional.
- Authentication, encryption, server sync, audit-grade attribution, and clinical validation remain mandatory before a real pilot.
